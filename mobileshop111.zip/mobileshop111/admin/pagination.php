<table border="1" cellpadding="5" cellspacing="5">
    <tr>
        <td>
            <a <?php if($page_no > 1){ 
                echo "href='?page_no=$previous_page.'&'.$query_string'";
                } ?>>Previous</a>
        </td>
        <?php for($counter = 1; $counter <= $total_no_of_pages; $counter++){
                if($counter == $page_no){
                    echo "<td><a>$counter</a></li>";
                }else{
                        $query_string = 'page_no='.$counter.$query_string; 
                        echo '<td><a href=?'.$query_string.">$counter</a></td>";
                    }
            }
        ?>
        <td>
            <a <?php if($page_no < $total_no_of_pages){ echo "href='?page_no=$next_page.'&'.$query_string'";} ?>>Next</a>
        </td>    
    </tr>
</table>