<?php
include('admin/connect.php');
session_start();

$prodid="";
$productqty = 1;
$addproduct=''; 

    if(isset($_GET['prod_id']) && $_GET['prod_id']!=''){
        $prodid=$_GET['prod_id'];   
    }

//<=====if login then-after view this addproduct=====>
if(isset($_SESSION['usr_name']) && isset($_SESSION['usr_id']))
{
    //<=====set the cookies=====>
    if($prodid!='' && !isset($_COOKIE['cart_data_'.$_SESSION['usr_id']])){
        
        setcookie('cart_data_'.$_SESSION['usr_id'], $prodid."$".$productqty."#", time() + 48 * 3600, '/');     // cart_data_1 = 31$1#
    }
    else{
        $prod_cookie = explode('#',$_COOKIE['cart_data_'.$_SESSION['usr_id']]);  
             //Array ( [0]=>30$1 [1] =>)
            
            foreach($prod_cookie as $value){
                $getprodid=explode('$',$value);  //Array ([0]=>30 [1]=>1)
                     
                if($getprodid['0']==$prodid){
                    header("Location:".SITE_URL."/index.php?msg=a");  //Product already Exists
                        exit;
                }
            }
        $newcookie=$_COOKIE['cart_data_'.$_SESSION['usr_id']].$prodid.'$1#';
        setcookie('cart_data_'.$_SESSION['usr_id'],$newcookie,time() + 48 * 3600,'/');
            header("Location:".SITE_URL."/index.php?msg=A");  //New Product Add to Cart
        exit;
        
    }
    header("Location:".SITE_URL."/index.php?msg=A");    
}
else{
    header("Location:".SITE_URL."/index.php?msg=L");  //please login
 }
?>