<?php
include('header.php');
?>
<tr><td width="100%">
	<table width="100%" border="0" >
      <tr>
         <td width="20%">
            <ul>
               <li><b>All category</b></li><br>
               <li><a href="">Mobile</a></li>
               <li><a href="">Laptop</a></li>
               <li><a href="">Camera</a></li>
               <li><a href="">Tv</a></li>
               <li><a href="">Watch</a></li>
               <li><a href="">Pc</a></li>
            </ul>
         </td>
         <td width="80%">
            <table width="100%" border="1">
               <tr>
                  <td>
                     <a href="">
                     <img src="http://192.168.0.1/test/bhavik/mobileshop/images/product/1675322497cover%20mobile2.jpeg">
                     TEst
                     </a>
                     $50
                     <a href="">Add To Cart</a>
                  </td>
                  <td>
                     <a href="">
                     <img src="http://192.168.0.1/test/bhavik/mobileshop/images/product/1675322497cover%20mobile2.jpeg">
                     TEst
                     </a>
                     $50
                     <a href="">Add To Cart</a>
                  </td>
                  <td>
                     <a href="">
                     <img src="http://192.168.0.1/test/bhavik/mobileshop/images/product/1675322497cover%20mobile2.jpeg">
                     TEst
                     </a>
                     $50
                     <a href="">Add To Cart</a>
                  </td>
                  
               </tr>
               <tr>
                  <td>
                    <a href="">
                     <img src="http://192.168.0.1/test/bhavik/mobileshop/images/product/1675322497cover%20mobile2.jpeg">
                     TEst
                     </a>
                     $50
                     <a href="">Add To Cart</a>
                  </td>
                  <td>
                    <a href="">
                     <img src="http://192.168.0.1/test/bhavik/mobileshop/images/product/1675322497cover%20mobile2.jpeg">
                     TEst
                     </a>
                     $50
                     <a href="">Add To Cart</a>
                  </td>
                  <td>
                     <a href="">
                     <img src="http://192.168.0.1/test/bhavik/mobileshop/images/product/1675322497cover%20mobile2.jpeg">
                     TEst
                     </a>
                     $50
                     <a href="">Add To Cart</a>
                  </td>
                  
               </tr>

            </table>

         </td>
      </tr>

	</table>
</td></tr>
<?php include('footer.php'); ?>
