<?php 
	include 'connect.php';
	session_start();
	require "function.php";

?>
<!DOCTYPE html>
<html>
<head> 
</head>
<body>

<table border="1" width="100%">
	<tr><td align="center">
		<table width="100%" align="center" border="1">
			<tr><td width="100%" align="center"><h1>BhavikShop</h1></td></tr>
		</table>
	</td></tr>