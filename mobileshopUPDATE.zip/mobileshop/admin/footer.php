  <tr><td align="center"><h4>@CopyRight Mobileshop</h4></td></tr>
</table>
<script>
  function deletelist(){
      if(confirm("Are you sure Delete Rocord?")){
          return true;
      }else{
          return false;
      }
  }
  function deleteimage(){
    if(confirm("Are you sure Delete Image?")){
        return true;
    }else{
        return false;
    }
  }
</script>
</body>
</html>